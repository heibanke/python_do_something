# -*- coding: utf-8 -*-
# comment by heibanke

import cv2

def onMouse(event, x, y, flags, param):
    global clicked
    if event == cv2.cv.CV_EVENT_LBUTTONUP:
        clicked = True

#实例化分类器
face_cascade = cv2.CascadeClassifier('./xml/haarcascade_frontalface.xml')
eye_cascade = cv2.CascadeClassifier('./xml/haarcascade_eye.xml')

clicked = False

cameraCapture = cv2.VideoCapture(0)
cv2.namedWindow('MyCamera')
cv2.setMouseCallback('MyCamera', onMouse)
print u'点击窗口或者按任意键退出.'
success, frame = cameraCapture.read()

while cv2.waitKey(1) == -1 and not clicked:
    if frame is not None:
        ###############################
        # 对图像进行人脸检测
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.2, 2)

        for (x,y,w,h) in faces:
            cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = frame[y:y+h, x:x+w]
            #在人脸检测的基础上检测眼睛
            eyes = eye_cascade.detectMultiScale(roi_gray)
            for (ex,ey,ew,eh) in eyes:
                cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
        #################################
        cv2.imshow('MyCamera', frame)
    success, frame = cameraCapture.read()

cv2.destroyWindow('MyCamera')